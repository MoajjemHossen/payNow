
<?php 





 ?>



<div style="display: flex; justify-content: center; align-items: center; height: 100vh; width: 100vw;" >

			<h3 style="background: #00800005; padding: 20px; color: #000;">

				<?php 

					if (isset($_REQUEST['submitbtn']) ) {
	
						$name = $_REQUEST['name'];
						echo $name;

					}
					
					

				?>
			</h3>
</div>


<p><center>Copy Rights are all Reserbed. &copy;</center></p>