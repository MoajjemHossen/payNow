
<div class="container-fluid ">
	<div class="wraper">
					<div class="main_div">
				<div class="form_title">
					<h1>Please input your infomation</h1>
				</div>
				<div class="form_fields">
					<form action="assets/pages/source.php" method="post" accept-charset="utf-8">

						<div class="form-group">
							<label for="">Full name</label>
							<input type="text" name="fullName" class="form-control" placeholder="Full Name ">
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">Email Address</label>
							<input type="text" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Email"></input>
							<small id="emailHelp" class="form-text text-muted">We'll never share your email whith anyone else.</small>
						</div>
						<div class="form-group">
							<label for="exampleInputNumber1">Mobile Number</label>
							<input type="text" name="cell_number" class="form-control" id="exampleInputNumber1" aria-describedby="numberHelp" placeholder="Enter Your Mobile Number"></input>
							<small id="numberHelp" class="form-text text-muted">We'll never share your number whith anyone else.</small>
						</div>
						<div class="form-group">
							<label for="exampleInputPassword1">Password</label>
							<input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
						</div>
						<div class="form-group form-check">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label for="exampleCheck1" class="form-check-label">Check me out.</label>
						</div>
						<button type="submit" name="submit" class="btn btn-primary">SignUp</button>

					</form>
				</div>
			</div>
			
		
	</div>
</div>









