
<div class="container-fluid ">
	<div class="wraper">
					<div class="main_div">
				<div class="form_title">
					<h1>Please input your infomation</h1>
				</div>
				<div class="form_fields">











					<form action="assets/inc/process.php" method="post" accept-charset="utf-8">

						<div class="form-group">
							<label for="exampleInputNumber1">Mobile/Email</label>
							<input type="text" name="number_email" class="form-control" id="exampleInputNumber1" placeholder="Number/Email">
						</div>
						<div class="form-group">
							<label for="exampleInputPassword1">Password</label>
							<input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
						</div>
						<div class="form-group form-check">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label for="exampleCheck1" class="form-check-label">Remember me</label>
						</div>
						<button type="submit" name="submitbtn" class="btn btn-primary">SignUp</button>

					</form>










				</div>
			</div>
			
		
	</div>
</div>


