<p><center>Copy Rights are all Reserbed. &copy;</center></p>

<script src="<?=site_url('assets/bootstrap/js/bootstrap.min.js')?>" type="text/javascript" charset="utf-8" async defer></script>
	
</body>
</html>