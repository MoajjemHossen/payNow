<?php require_once ( "assets/inc/functions.php" ); 

 ?>
<?php
//header ongsho add kora hoiche
view_parts('header', 'payNow-easy send money');

//pages add kora hoiche
// view_page('signup', 'New Reagistration');
view_page('signIn', 'New login');

//footer section add kora hoiche
view_parts('footer');

 ?>

